# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ppds']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.10.0,<5.0.0',
 'pandas>=1.4.1,<2.0.0',
 'requests>=2.27.1,<3.0.0',
 'tinydb>=4.6.1,<5.0.0']

setup_kwargs = {
    'name': 'ppds',
    'version': '0.1.0',
    'description': 'A propeller dataset for Aerodesign teams.',
    'long_description': None,
    'author': 'Pampa Aerodesing',
    'author_email': 'aerodesign@ufrgs.br',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
